package main

import (
	"github.com/StratuStore/file-storage/internal/app/app"
)

func main() {
	app.Run()
}
